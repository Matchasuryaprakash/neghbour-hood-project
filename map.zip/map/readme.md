# Udacity Project: Neighborhood Map

## How to run it?

* Open index.html file in your favorite browser.

## What does it do?
It displays a map with my favorite locations in the neighborhood I live in.
There is a button named menu that toggles the navigation sidebar.
If you click in a location on the side bar or in one of the markers in the map,
it will query wikipedia's API for articles related to the location name and display links in a infoWindow.
You can also filter the locations by typing into the input box located at the top of the navigation sidebar.

